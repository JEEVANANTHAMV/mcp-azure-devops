---
name: azure-devops-automation
display_name: "Azure DevOps MCP (44 tools, offline / PAT)"
description: "Drive Microsoft Azure DevOps (projects, work-items, pipelines, boards, repos, releases, test plans, security) through 44 stdio MCP tools. Offline-self-contained: prebuilt dist/ + vendored node_modules, no runtime npm install. Authenticate with a base64 Personal Access Token via PERSONAL_ACCESS_TOKEN and an organization positional arg. Use when an operator or agent needs to query or mutate Azure DevOps data (list projects, read/write work items, trigger/list builds, manage branches and repos, create releases, run queries) without a browser."
---

# Azure DevOps MCP - effective-use skill

This MCP server is Microsoft's official **Azure DevOps** MCP server
(`@azure-devops/mcp` v2.10.0) bundled for **offline** use.

## What ships
- `dist/`  - prebuilt JavaScript (run this; do NOT recompile).
- `node_modules/` - all production dependencies vendored (offline).
- `src/`   - original TypeScript (for reference / rebuilds).
- `package.json` (`bin`: `mcp-server-azuredevops` -> `dist/index.js`).

## Invocation (mcp.json)
    command : node
    args    : [ <INSTALL_DIR>/dist/index.js , <ORG>, --authentication, pat ]
    env     : PERSONAL_ACCESS_TOKEN=<PAT base64>   LOG_LEVEL=info

- `<ORG>` = Azure DevOps organization **name or full URL** (first positional).
- `PERSONAL_ACCESS_TOKEN` = the **base64-encoded** PAT.

## Tool families (44 total)
    core_*        list projects / teams, get identities, org security
    work_*        work-item CRUD, iterations, capacity, queries, links
    pipelines_*   builds, definitions, runs, run logs, schedules, variables
    boards_*      boards, cards, iterations, areas
    repos_*       repositories, branches, commits, pulls, refs, tags, push
    releases_*    definitions, deployments, artifacts
    test_*        plans, suites, runs, results
    accounts_*    org / user / identity administration
    security_*    roles, policies, audit
    (see `tools/list` for the authoritative set)

## Auth (PAT)
1. Create a PAT at <https://dev.azure.com/<org>/_usersSettings/tokens>.
2. Give it the scopes that match the tools you intend to call.
3. Base64-encode it:
        PowerShell:  [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("<pat>"))

## Common recipes
- **List projects**: tool `core_list_projects` (no args beyond server config).
- **List a project's teams**: `core_list_project_teams`.
- **Read a work item**: `work_item_get_work_item` with `id`.
- **Create a work item**: `work_item_update_work_item` / relevant create tool.
- **Trigger a build**: `pipelines_build` / `pipelines_run`.
- **List pipeline runs**: `pipelines_run`.

## Verification (offline, at build time)
Probe over stdio: `initialize` -> ok, `tools/list` -> **44 tools**.
`node dist/index.js --help` prints usage with `--authentication pat`.

## Failure modes
- Missing/invalid PAT -> server starts but calls return 401/403.
- Wrong org name -> server starts; domain-scoped tools return 404.
- Node not on PATH at install time -> point `command` at an absolute node.exe.
