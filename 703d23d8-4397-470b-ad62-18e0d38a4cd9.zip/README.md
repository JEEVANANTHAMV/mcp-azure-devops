# Azure DevOps MCP Server (offline, self-contained)

Microsoft's official **Azure DevOps MCP server** (`@azure-devops/mcp` v2.10.0),
bundled **offline** so no `npm install` is ever needed at install time.
`node_modules` is fully populated in the bundle and the TypeScript source has
already been compiled to `dist/` — the runtime just runs the prebuilt output.

* **Server:** `dist/index.js` (compiled). `npm` is NOT required at install time.
* **Transport:** stdio (MCP).
* **Tools:** 44 (all Azure DevOps domains: core/projects, work-items, pipelines,
  boards, repos, releases, test plans, accounts/security).
* **Auth:** Personal Access Token (PAT), base64-encoded, supplied via
  `PERSONAL_ACCESS_TOKEN`.

## Layout

    dist/                  compiled server (run this)
    src/                   original TypeScript source
    node_modules/          all production deps, pre-installed (offline)
    package.json           bin: mcp-server-azuredevops -> dist/index.js

## How to configure (end user)

1. Set your Azure DevOps **organization** (used as the first positional arg):
   - org name, e.g. `Contoso`, OR
   - full URL, e.g. `https://dev.azure.com/Contoso`.
2. Create a **PAT** with the scopes you need (e.g. `Work Items (Read/Write)`,
   `Build (Read)`, `Code (Read)`) at
   <https://dev.azure.com/{org}/_usersSettings/tokens>.
3. **Base64-encode** the PAT (the server decodes it):
   PowerShell:        `[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("<pat>"))`
   - Do NOT paste the raw secret into this file; the registry injects it.
4. Point the env placeholders in `mcp.json` at your values (the install flow
   substitutes `__ADO_ORG__` / `__ADO_PAT__`).

> The `organization` argument is a **positional CLI arg**, not an env var. If your
> org is unusual, adjust `mcp.json` `args` directly.

## mcp.json (as bundled)

    {
      "command": "node",
      "args": ["__INSTALL_DIR__\\dist\\index.js", "__ADO_ORG__", "--authentication", "pat"],
      "env": { "PERSONAL_ACCESS_TOKEN": "__ADO_PAT__", "LOG_LEVEL": "info" }
    }

The `command` must be the Windows `node` executable. On a clean target machine
install the LTS Node (this bundle was built with Node 24); alternatively point
`command` at a specific node.exe path if the bundle must be self-contained.

## env variables
    __ADO_ORG__   (required) Azure DevOps org name or full URL.
    __ADO_PAT__   (required) base64-encoded Personal Access Token.
    LOG_LEVEL     (optional) info | debug | warn | error.

## Test (offline)

With a real PAT:

    node dist/index.js <your-org> --authentication pat

and drive it with an MCP client that sets `PERSONAL_ACCESS_TOKEN`. The same
probe used at build time listed **44 tools** and the `initialize` handshake
succeeded end-to-end.
